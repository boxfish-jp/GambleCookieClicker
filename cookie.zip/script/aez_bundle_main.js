function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;
    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }
    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }
          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }
        return n[i].exports;
      }
      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
      return o;
    }
    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * コンバータ機能を提供するクラス。
       */
      var Converter = /** @class */function () {
        function Converter() {}
        /**
         * エンティティをホバー可能に変換する。
         */
        Converter.asHoverable = function (e, opts) {
          var hoverableE = e;
          hoverableE.hoverable = true;
          hoverableE.touchable = true;
          hoverableE.hovered = hoverableE.hovered || new g.Trigger();
          hoverableE.unhovered = hoverableE.unhovered || new g.Trigger();
          if (opts) {
            if (opts.cursor) hoverableE.cursor = opts.cursor;
          }
          return hoverableE;
        };
        /**
         * エンティティのホバーを解除する。
         */
        Converter.asUnhoverable = function (e) {
          var hoverableE = e;
          delete hoverableE.hoverable;
          if (hoverableE.hovered && !hoverableE.hovered.destroyed()) {
            hoverableE.hovered.destroy();
            delete hoverableE.hovered;
          }
          if (hoverableE.unhovered && !hoverableE.unhovered.destroyed()) {
            hoverableE.unhovered.fire();
            hoverableE.unhovered.destroy();
            delete hoverableE.unhovered;
          }
          return hoverableE;
        };
        return Converter;
      }();
      exports.Converter = Converter;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * ホバー機能を提供するプラグイン。
       */
      var HoverPlugin = /** @class */function () {
        function HoverPlugin(game, view, option) {
          if (option === void 0) {
            option = {};
          }
          this.game = game;
          this.view = view.view;
          this.beforeHover = null;
          this.operationTrigger = new g.Trigger();
          this._cursor = option.cursor || "pointer";
          this._showTooltip = !!option.showTooltip;
          this._getScale = view.getScale ? function () {
            return view.getScale();
          } : null;
          this._onMouseMove_bound = this._onMouseMove.bind(this);
          this._onMouseOut_bound = this._onMouseOut.bind(this);
        }
        HoverPlugin.isSupported = function () {
          return typeof document !== "undefined" && typeof document.addEventListener === "function";
        };
        HoverPlugin.prototype.start = function () {
          this.view.addEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.addEventListener("mouseout", this._onMouseOut_bound, false);
          return true;
        };
        HoverPlugin.prototype.stop = function () {
          this.view.removeEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.removeEventListener("mouseout", this._onMouseOut_bound, false);
        };
        HoverPlugin.prototype._onMouseMove = function (e) {
          var scene = this.game.scene();
          if (!scene) return;
          var rect = this.view.getBoundingClientRect();
          var positionX = rect.left + window.pageXOffset;
          var positionY = rect.top + window.pageYOffset;
          var offsetX = e.pageX - positionX;
          var offsetY = e.pageY - positionY;
          var scale = {
            x: 1,
            y: 1
          };
          if (this._getScale) {
            scale = this._getScale();
          }
          var point = {
            x: offsetX / scale.x,
            y: offsetY / scale.y
          };
          var target = scene.findPointSourceByPoint(point).target;
          if (target && target.hoverable) {
            if (target !== this.beforeHover) {
              if (this.beforeHover && this.beforeHover.hoverable) {
                this._onUnhovered(target);
              }
              this._onHovered(target);
            }
            this.beforeHover = target;
          } else if (this.beforeHover) {
            this._onUnhovered(this.beforeHover);
          }
        };
        HoverPlugin.prototype._onHovered = function (target) {
          if (target.hoverable) {
            this.view.style.cursor = target.cursor ? target.cursor : this._cursor;
            if (this._showTooltip && target.title) {
              this.view.setAttribute("title", target.title);
            }
            target.hovered.fire();
          }
        };
        HoverPlugin.prototype._onUnhovered = function (target) {
          this.view.style.cursor = "auto";
          if (this.beforeHover && this.beforeHover.unhovered) {
            this.beforeHover.unhovered.fire();
            if (this._showTooltip) {
              this.view.removeAttribute("title");
            }
          }
          this.beforeHover = null;
        };
        HoverPlugin.prototype._onMouseOut = function () {
          if (this.beforeHover) this._onUnhovered(this.beforeHover);
        };
        return HoverPlugin;
      }();
      exports.HoverPlugin = HoverPlugin;
      module.exports = HoverPlugin;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      var Converter_1 = require("./Converter");
      exports.Converter = Converter_1.Converter;
    }, {
      "./Converter": 1
    }],
    4: [function (require, module, exports) {
      "use strict";

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
          return t;
        };
        return __assign.apply(this, arguments);
      };
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FallbackDialog = void 0;
      var akashic_hover_plugin_1 = require("@akashic-extension/akashic-hover-plugin");
      var HoverPluginRaw = require("@akashic-extension/akashic-hover-plugin/lib/HoverPlugin");
      // Ugh! HoverPlugin が Akashic Engine 向けに中途半端に CommonJS で (module.exports = HoverPlugin と)
      // 定義されている関係で、 import すると TS の型と実体が合わない。無理やり解消する。
      // (import * as ... すると、 JS 的には HoverPlugin の実体が手に入るが、TS 上では namespace と誤認される)
      // さらにおそらく akashic-hover-plugin 側のバグで、型があっていないのでそれも無理やり合わせる。
      // (コンストラクタ第二引数が間違っている。実装上は any キャストして正しく使っている)
      var HoverPlugin = HoverPluginRaw;
      function drawCircle(rendr, centerX, centerY, radius, cssColor) {
        for (var y = centerY - radius | 0; y <= Math.ceil(centerY + radius); ++y) {
          var w = radius * Math.cos(Math.asin((centerY - y) / radius));
          rendr.fillRect(centerX - w, y, 2 * w, 1, cssColor);
        }
      }
      function makeSurface(w, h, drawer) {
        var s = g.game.resourceFactory.createSurface(Math.ceil(w), Math.ceil(h));
        var r = s.renderer();
        r.begin();
        drawer(r);
        r.end();
        return s;
      }
      function animate(e, motions) {
        var onEnd = new g.Trigger();
        var frameTime = 1000 / g.game.fps;
        var step = 0;
        var time = 0;
        var mot = motions[0];
        var ended = false;
        function update(delta) {
          time += delta;
          if (time > mot.duration) {
            ended = ++step >= motions.length;
            if (ended) {
              time = mot.duration;
              e.scene.onUpdate.addOnce(onEnd.fire, onEnd);
            } else {
              time -= mot.duration;
              mot = motions[step];
            }
          }
          var r = Math.min(1, time / mot.duration);
          var scale = mot.scale,
            opacity = mot.opacity;
          if (scale) e.scaleX = e.scaleY = scale[0] + (scale[1] - scale[0]) * r;
          if (opacity) e.opacity = opacity[0] + (opacity[1] - opacity[0]) * r;
          e.modified();
          return ended;
        }
        update(0);
        e.onUpdate.add(function () {
          return update(frameTime);
        });
        return onEnd;
      }
      var FallbackDialog = /** @class */function () {
        function FallbackDialog(name) {
          var _this = this;
          this.onEnd = new g.Trigger();
          this.isHoverPluginStarted = false;
          this.timer = null;
          if (!FallbackDialog.isSupported()) return;
          var game = g.game;
          var gameWidth = game.width,
            gameHeight = game.height;
          var baseWidth = 1280;
          var ratio = gameWidth / baseWidth;
          var titleFontSize = Math.round(32 * ratio);
          var fontSize = Math.round(28 * ratio);
          var lineMarginRate = 0.3;
          var lineHeightRate = 1 + lineMarginRate;
          var titleTopMargin = 80 * ratio;
          var titleBotMargin = 32 * ratio;
          var buttonTopMargin = 42 * ratio;
          var buttonWidth = 360 * ratio;
          var buttonHeight = 82 * ratio;
          var buttonBotMargin = 72 * ratio;
          var colorBlue = "#4a8de1";
          var colorWhite = "#fff";
          var dialogWidth = 960 * ratio | 0;
          var dialogHeight = titleTopMargin + titleFontSize * lineHeightRate * 2 + titleBotMargin + (fontSize + fontSize * lineHeightRate) +
          // 一行目のマージンは titleBotMargin に繰り込まれている
          buttonTopMargin + buttonHeight + buttonBotMargin | 0;
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            size: titleFontSize,
            fontWeight: g.FontWeight.Bold,
            fontColor: "#252525"
          });
          var surfSize = Math.ceil(32 * ratio) & ~1; // 切り上げて偶数に丸める
          var surfHalf = surfSize / 2;
          var dialogBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorWhite);
          });
          var btnActiveBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
          });
          var btnBgSurf = makeSurface(surfSize, surfSize, function (r) {
            drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
            drawCircle(r, surfHalf, surfHalf, 12 * ratio, colorWhite);
          });
          function makeLabel(param) {
            return new g.Label(__assign({
              scene: scene,
              font: font,
              local: true,
              textAlign: g.TextAlign.Center,
              widthAutoAdjust: false
            }, param));
          }
          var scene = this.scene = game.scene();
          var bg = this.bgRect = new g.FilledRect({
            scene: scene,
            local: true,
            width: gameWidth,
            height: gameHeight,
            cssColor: "rgba(0, 0, 0, 0.5)",
            touchable: true // 後ろの touch を奪って modal にする
          });

          var dialogPane = this.dialogPane = new g.Pane({
            scene: scene,
            local: true,
            width: dialogWidth,
            height: dialogHeight,
            anchorX: 0.5,
            anchorY: 0.5,
            x: game.width / 2 | 0,
            y: game.height / 2 | 0,
            backgroundImage: dialogBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, dialogBgSurf.width / 2 - 1),
            parent: bg
          });
          var dialogTextX = 80 * ratio | 0;
          var dialogTextWidth = 800 * ratio | 0;
          var y = 0;
          y += titleTopMargin + titleFontSize * lineMarginRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "このコンテンツは名前を利用します。",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "\u3042\u306A\u305F\u306F\u300C" + name + "\u300D\u3067\u3059\u3002",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize + titleBotMargin | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "ユーザ名で参加するには、",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "最新のニコニコ生放送アプリに更新してください。",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize + buttonTopMargin | 0;
          var buttonPane = new g.Pane({
            scene: scene,
            local: true,
            width: buttonWidth,
            height: buttonHeight,
            x: dialogWidth / 2,
            y: y + buttonHeight / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            backgroundImage: btnBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, btnBgSurf.width / 2 - 1),
            parent: scene,
            touchable: true
          });
          dialogPane.append(buttonPane);
          var buttonLabel = this.buttonLabel = makeLabel({
            x: 0,
            y: (buttonHeight - titleFontSize) / 2 - 5 * ratio,
            text: "OK (15)",
            fontSize: titleFontSize,
            width: buttonWidth,
            textColor: colorBlue
          });
          buttonPane.append(buttonLabel);
          var activateButton = function activateButton() {
            buttonPane.backgroundImage = btnActiveBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorWhite;
            buttonLabel.invalidate();
          };
          var deactivateButton = function deactivateButton() {
            buttonPane.backgroundImage = btnBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorBlue;
            buttonLabel.invalidate();
          };
          var h = akashic_hover_plugin_1.Converter.asHoverable(buttonPane);
          var animating = false;
          h.hovered.add(function () {
            activateButton();
            if (animating) return;
            animating = true;
            animate(buttonPane, [{
              duration: 16,
              scale: [1.0, 0.9]
            }, {
              duration: 16,
              scale: [0.9, 1.1]
            }, {
              duration: 33,
              scale: [1.1, 1.0]
            }]).add(function () {
              return animating = false;
            });
          });
          h.unhovered.add(deactivateButton);
          buttonPane.onPointDown.add(activateButton);
          buttonPane.onPointUp.add(function () {
            _this.end();
          });
          if (!game.operationPluginManager.plugins[FallbackDialog.HOVER_PLUGIN_OPCODE]) game.operationPluginManager.register(HoverPlugin, FallbackDialog.HOVER_PLUGIN_OPCODE);
        }
        FallbackDialog.isSupported = function () {
          // 縦横比 0.4 について: このダイアログは 16:9 の解像度で画面高さの約 65% (468px) を占有する。
          // すなわち画面高さが画面幅の約 37% 以下の場合画面に収まらない。余裕を見て 40% を下限とする。
          // (詳細な高さは下の dialogHeight の定義を参照せよ)
          return typeof window !== "undefined" && g.game.height / g.game.width >= 0.4 && HoverPlugin.isSupported();
        };
        FallbackDialog.prototype.start = function (remainingSeconds) {
          var _this = this;
          var game = g.game;
          var scene = this.scene;
          if (game.scene() !== scene) {
            // ないはずの異常系だが一応確認
            return;
          }
          // エッジケース考慮: hoverプラグインは必ず停止したいので、シーンが変わった時点で止めてしまう。
          // (mouseover契機で無駄にエンティティ検索したくない)
          game.onSceneChange.add(this._disablePluginOnSceneChange, this);
          game.operationPluginManager.start(FallbackDialog.HOVER_PLUGIN_OPCODE);
          this.isHoverPluginStarted = true;
          animate(this.dialogPane, [{
            duration: 100,
            scale: [0.5, 1.1],
            opacity: [0.5, 1.0]
          }, {
            duration: 100,
            scale: [1.1, 1.0],
            opacity: [1.0, 1.0]
          }]);
          scene.append(this.bgRect);
          scene.onUpdate.add(this._assureFrontmost, this);
          this.timer = scene.setInterval(function () {
            remainingSeconds -= 1;
            _this.buttonLabel.text = "OK (" + remainingSeconds + ")";
            _this.buttonLabel.invalidate();
            if (remainingSeconds <= 0) {
              _this.end();
            }
          }, 1000);
        };
        FallbackDialog.prototype.end = function () {
          var _this = this;
          if (this.timer) {
            this.scene.clearInterval(this.timer);
            this.timer = null;
          }
          // 厳密には下のアニメーション終了後に解除する方がよいが、
          // 途中でシーンが破棄されるエッジケースを想定してこの時点で止める。
          this.scene.onUpdate.remove(this._assureFrontmost, this);
          if (this.isHoverPluginStarted) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            this.isHoverPluginStarted = false;
          }
          animate(this.dialogPane, [{
            duration: 100,
            opacity: [1, 0],
            scale: [1, 0.8]
          }]);
          var t = animate(this.bgRect, [{
            duration: 100,
            opacity: [1, 0]
          }]);
          t.add(function () {
            var onEnd = _this.onEnd;
            _this.onEnd = null;
            _this.bgRect.destroy();
            _this.bgRect = null;
            _this.dialogPane = null;
            _this.scene = null;
            onEnd.fire();
          });
        };
        FallbackDialog.prototype._disablePluginOnSceneChange = function (scene) {
          if (scene !== this.scene) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            return true;
          }
        };
        // フレーム終了時に確実に画面最前面に持ってくる
        FallbackDialog.prototype._assureFrontmost = function () {
          g.game._pushPostTickTask(this._doAssureFrontmost, this);
        };
        FallbackDialog.prototype._doAssureFrontmost = function () {
          var scene = this.scene;
          if (scene && g.game.scene() !== scene) return;
          if (scene.children[scene.children.length - 1] === this.bgRect) return;
          this.bgRect.remove();
          scene.append(this.bgRect);
        };
        FallbackDialog.HOVER_PLUGIN_OPCODE = -1000; // TODO: 定数予約
        return FallbackDialog;
      }();
      exports.FallbackDialog = FallbackDialog;
    }, {
      "@akashic-extension/akashic-hover-plugin": 3,
      "@akashic-extension/akashic-hover-plugin/lib/HoverPlugin": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.resolvePlayerInfo = void 0;
      var FallbackDialog_1 = require("./FallbackDialog");
      var rpgAtsumaru = typeof window !== "undefined" ? window.RPGAtsumaru : undefined;
      function createRandomName() {
        return "ゲスト" + (Math.random() * 1000 | 0);
      }
      var resolvers = [
      // window.RPGAtsumaru
      {
        isSupported: function isSupported() {
          return !!(rpgAtsumaru && rpgAtsumaru.user && rpgAtsumaru.user.getSelfInformation);
        },
        resolve: function resolve(_limitSeconds, callback) {
          rpgAtsumaru.user.getSelfInformation().then(function (selfInfo) {
            callback(null, {
              name: selfInfo.name,
              userData: {
                accepted: true,
                premium: selfInfo.isPremium
              }
            });
          }, function (err) {
            callback(err, null);
          });
        }
      },
      // coeLimited
      {
        isSupported: function isSupported() {
          var coeLimited = g.game.external.coeLimited;
          return !!(coeLimited && coeLimited.startLocalSession && coeLimited.exitLocalSession);
        },
        resolve: function resolve(limitSeconds, callback) {
          var sessionId = g.game.playId + "__player-info-resolver";
          var scene = g.game.scene();
          var timeoutId = scene.setTimeout(function () {
            timeoutId = null;
            // NOTE: スキップ時は既に終了済みのローカルセッション自体が起動せず messageHandler() も呼ばれなるため、
            // ここで callback() を呼ばないとコンテンツ側がコールバックをいつまでも待ってしまう状態になってしまう
            callback(null, {
              name: null,
              userData: {
                accepted: false,
                premium: false
              }
            });
            // NOTE: リアルタイム視聴の場合、大半のケースではこちらのパスには到達しないはず
            // (仮に到達しても同一セッションIDの COE#exitSession() が呼ばれるのみ)
            // 追っかけ再生またはタイムシフトによる視聴においては、
            // player-info-resolver の自発終了よりも先に以下の exitLocalSession() を呼ぶことで
            // 「スキップ中のセッション起動を抑止する」というプラットフォーム側の機能を有効にしている
            g.game.external.coeLimited.exitLocalSession(sessionId, {
              needsResult: true
            });
          }, (limitSeconds + 2) * 1000); // NOTE: 読み込みなどを考慮して 2 秒のバッファを取る
          g.game.external.coeLimited.startLocalSession({
            sessionId: sessionId,
            applicationName: "player-info-resolver",
            localEvents: [[32, 0, ":akashic", {
              type: "start",
              parameters: {
                limitSeconds: limitSeconds
              }
            }]],
            messageHandler: function messageHandler(message) {
              if (timeoutId == null) {
                // 先にタイムアウト処理が実行されていたら何もしない
                return;
              }
              scene.clearTimeout(timeoutId);
              // TODO 引数からエラーを取得できるようになったら、異常系の処理も行う
              callback(null, message.result);
            }
          });
        }
      },
      // g.game.external.atsumaru
      {
        isSupported: function isSupported() {
          var atsumaru = g.game.external.atsumaru;
          return !!(atsumaru && atsumaru.getSelfInformationProto);
        },
        resolve: function resolve(_limitSeconds, _callback) {
          g.game.external.atsumaru.getSelfInformationProto({
            callback: function callback(errorMessage, result) {
              if (errorMessage != null) {
                _callback(new Error(errorMessage), null);
                return;
              }
              if (result && result.login) {
                _callback(null, {
                  name: result.name,
                  userData: {
                    accepted: true,
                    premium: result.premium
                  }
                });
              } else {
                _callback(null, {
                  name: createRandomName(),
                  userData: {
                    accepted: false,
                    premium: false
                  }
                });
              }
            }
          });
        }
      },
      // FallbackDialog
      {
        isSupported: FallbackDialog_1.FallbackDialog.isSupported,
        resolve: function resolve(limitSeconds, callback) {
          var name = createRandomName();
          var dialog = new FallbackDialog_1.FallbackDialog(name);
          dialog.start(limitSeconds);
          dialog.onEnd.addOnce(function () {
            callback(null, {
              name: name,
              userData: {
                accepted: false,
                premium: false
              }
            });
          });
        }
      },
      // sentinel
      {
        isSupported: function isSupported() {
          return true;
        },
        resolve: function resolve(_limitSeconds, callback) {
          callback(null, {
            name: "",
            userData: {
              accepted: false,
              premium: false,
              unnamed: true
            }
          });
        }
      }];
      var DEFAULT_LIMIT_SECONDS = 15;
      // resolvePlayerInfo() の多重呼び出し防止フラグ
      var isResolving = false;
      function find(xs, pred) {
        for (var i = 0; i < xs.length; ++i) {
          if (pred(xs[i])) return xs[i];
        }
        return undefined;
      }
      /**
       * ユーザー情報の取得と通知を行う
       * @param opts ユーザ情報取得時のオプション
       * @param callback 指定された場合、playerInfo が取得成功・失敗した時点の次の local/non-local tick で呼び出される
       */
      exports.resolvePlayerInfo = function (opts, callback) {
        if (isResolving) {
          callback === null || callback === void 0 ? void 0 : callback(new Error("Last processing has not yet been completed."), null);
          return;
        }
        var cb = function cb(err, info) {
          isResolving = false;
          callback === null || callback === void 0 ? void 0 : callback(err, info);
          if (!err) {
            var _a = info,
              name_1 = _a.name,
              userData = _a.userData;
            if (opts && opts.raises && (!userData || !userData.unnamed)) {
              g.game.raiseEvent(new g.PlayerInfoEvent({
                id: g.game.selfId,
                name: name_1,
                userData: userData
              }));
            }
          }
        };
        var limitSeconds = opts && opts.limitSeconds ? opts.limitSeconds : DEFAULT_LIMIT_SECONDS;
        var resolver = find(resolvers, function (r) {
          return r.isSupported();
        }); // isSupported() が恒真の実装があるので non-null
        try {
          isResolving = true;
          resolver.resolve(limitSeconds, cb);
        } catch (e) {
          cb(e);
        }
      };
    }, {
      "./FallbackDialog": 4
    }],
    6: [function (require, module, exports) {
      var resolvePlayerInfo = require("@akashic-extension/resolve-player-info").resolvePlayerInfo;
      var gambleTime = false; // 賭け中かどうか
      var resultPending = false; // 結果待ちかどうか
      // 参加者の情報を保持するテーブル
      var playersTable = {};
      var firstGamble = true; // 初回賭けかどうか

      // 放送者のみ表示
      // 賭けの設定ができる
      function streamer(scene, font, streamerLayer, playersTable) {
        var choiceNum = 0;
        var scoreSum = new g.Label({
          scene: scene,
          font: font,
          parent: streamerLayer,
          text: "総スコア数0個",
          anchorX: 0.5,
          anchorY: 0.5,
          fontSize: 20,
          textColor: "#593018",
          x: 500,
          y: 470,
          scaleX: 1,
          scaleY: 1,
          touchable: true,
          local: true
        });
        var choiceIndi = new g.Label({
          scene: scene,
          font: font,
          parent: streamerLayer,
          text: "選択中",
          anchorX: 0.5,
          anchorY: 0.5,
          fontSize: 25,
          textColor: "#593018",
          x: 500,
          y: 520,
          scaleX: 1,
          scaleY: 1,
          touchable: true,
          local: true
        });
        var explain = new g.Label({
          scene: scene,
          font: font,
          parent: streamerLayer,
          text: "ギャンブルを始めるには,下のボタンで何択の賭けをするか入力してから、「賭け!」ボタンを押してください",
          fontSize: 25,
          textColor: "#593018",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 640,
          y: 570
        });
        var choiceNum1 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 200,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          opacity: 0,
          src: scene.asset.getImageById("key1"),
          touchable: false,
          local: true
        });
        var choiceNum2 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 300,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key2"),
          touchable: true,
          local: true
        });
        var choiceNum3 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 400,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key3"),
          touchable: true,
          local: true
        });
        var choiceNum4 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 500,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key4"),
          touchable: true,
          local: true
        });
        var choiceNum5 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 600,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key5"),
          touchable: true,
          local: true
        });
        var choiceNum6 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 700,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key6"),
          touchable: true,
          local: true
        });
        var choiceNum7 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 800,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key7"),
          touchable: true,
          local: true
        });
        var choiceNum8 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 900,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key8"),
          touchable: true,
          local: true
        });
        var choiceNum9 = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1000,
          y: 640,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key9"),
          touchable: true,
          local: true
        });
        var startGamble = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 700,
          y: 250,
          scaleX: 1,
          scaleY: 1,
          src: scene.asset.getImageById("startGamble"),
          touchable: true,
          local: true
        });
        var closeGamble = new g.Sprite({
          scene: scene,
          parent: streamerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 700,
          y: 300,
          scaleX: 1,
          scaleY: 1,
          opacity: 0,
          src: scene.asset.getImageById("close"),
          touchable: false,
          local: true
        });
        var close;
        scene.onUpdate.add(function () {
          var totalScore = 0;
          for (var key in playersTable) {
            if (playersTable.hasOwnProperty(key)) {
              totalScore += playersTable[key].score;
            }
          }
          scoreSum.text = "総クッキー数" + totalScore.toString() + "個";
          scoreSum.invalidate();
          if (gambleTime) {
            startGamble.touchable = false;
            startGamble.opacity = 0;
            startGamble.modified();
          } else {
            startGamble.touchable = true;
            startGamble.opacity = 1;
            startGamble.modified();
          }
        });
        function choiceSelect(num) {
          if (!gambleTime) {
            choiceNum = num;
            choiceIndi.text = choiceNum.toString() + "個の選択肢で賭けを始める";
            choiceIndi.invalidate();
          } else if (resultPending) {
            resultPending = false;
            g.game.raiseEvent(new g.MessageEvent({
              result: num
            }));
            gambleTime = false;
            explain.text = "ギャンブルを始めるには,下のボタンで何択の賭けをするか入力してから、「賭け!」ボタンを押してください";
            explain.invalidate();
            choiceNum1.touchable = false;
            choiceNum1.opacity = 0;
            choiceNum1.modified();
          }
          console.log("resultPending", resultPending);
        }
        choiceNum1.onPointDown.add(function () {
          choiceSelect(1);
        });
        choiceNum2.onPointDown.add(function () {
          choiceSelect(2);
        });
        choiceNum3.onPointDown.add(function () {
          choiceSelect(3);
        });
        choiceNum4.onPointDown.add(function () {
          choiceSelect(4);
        });
        choiceNum5.onPointDown.add(function () {
          choiceSelect(5);
        });
        choiceNum6.onPointDown.add(function () {
          choiceSelect(6);
        });
        choiceNum7.onPointDown.add(function () {
          choiceSelect(7);
        });
        choiceNum8.onPointDown.add(function () {
          choiceSelect(8);
        });
        choiceNum9.onPointDown.add(function () {
          choiceSelect(9);
        });
        startGamble.onPointDown.add(function () {
          if (!choiceNum) return;
          g.game.raiseEvent(new g.MessageEvent({
            startGamble: true,
            choiceNum: choiceNum
          }));
          closeGamble.touchable = true;
          closeGamble.opacity = 1;
          closeGamble.modified();
          explain.text = "投票を締め切るには、「締め切り」ボタンを押しましょう";
          explain.invalidate();
        });
        closeGamble.onPointDown.add(function () {
          g.game.raiseEvent(new g.MessageEvent({
            closeGamble: true
          }));
          closeGamble.touchable = false;
          closeGamble.opacity = 0;
          closeGamble.modified();
          choiceNum1.touchable = true;
          choiceNum1.opacity = 1;
          choiceNum1.modified();
          resultPending = true;
          explain.text = "正解の選択肢を下のボタンで入力してください";
          explain.invalidate();
        });
      }

      // ユーザー名の設定
      function register(scene, font, registerLayer, cookieLayer, rankingLayer) {
        var registerImage = new g.Sprite({
          scene: scene,
          parent: registerLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 110,
          y: 180,
          scaleX: 0.6,
          scaleY: 0.6,
          src: scene.asset.getImageById("cookie"),
          touchable: true,
          local: true
        });
        registerImage.onPointDown.add(function () {
          resolvePlayerInfo({
            raises: true
          });
          registerLayer.hide();
          cookieClick(scene, font, cookieLayer);
          ranking(scene, font, rankingLayer);
        });
      }

      // クッキークリッカー
      function cookieClick(scene, font, cookieLayer) {
        var score = 0;
        var time = 0;
        var autoClicker = 0;
        function click() {
          g.game.raiseEvent(new g.MessageEvent({
            click: score
          }));
          cookieCounter.text = score.toString() + "枚";
          cookieCounter.invalidate();
        }
        var cookieCounter = new g.Label({
          scene: scene,
          parent: cookieLayer,
          font: font,
          textColor: "#593018",
          anchorX: 0.5,
          anchorY: 0.5,
          text: "0枚",
          fontSize: 50,
          x: 110,
          y: 55,
          local: true
        });
        var clickSpeed = new g.Label({
          scene: scene,
          parent: cookieLayer,
          font: font,
          textColor: "#F2D3AC",
          anchorX: 0.5,
          anchorY: 0.5,
          text: "分速0枚",
          fontSize: 25,
          x: 110,
          y: 95,
          local: true
        });
        var cookie = new g.Sprite({
          scene: scene,
          parent: cookieLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 110,
          y: 180,
          scaleX: 0.6,
          scaleY: 0.6,
          src: scene.asset.getImageById("cookie"),
          touchable: true,
          local: true
        });
        var shop = new g.Sprite({
          scene: scene,
          parent: cookieLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 220,
          y: 170,
          scaleX: 0.2,
          scaleY: 0.2,
          src: scene.asset.getImageById("shop"),
          touchable: true,
          local: true
        });
        var autoClick = new g.Sprite({
          scene: scene,
          parent: cookieLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 180,
          y: 300,
          scaleX: 0.5,
          scaleY: 0.5,
          src: scene.asset.getImageById("autoClick"),
          touchable: false,
          opacity: 0,
          local: true
        });
        cookie.onPointDown.add(function () {
          score++;
          click();
          cookie.scaleX = 0.65;
          cookie.scaleY = 0.65;
          cookie.modified();
        });
        cookie.onPointUp.add(function () {
          cookie.scaleX = 0.6;
          cookie.scaleY = 0.6;
          cookie.modified();
        });
        autoClick.onPointDown.add(function () {
          autoClicker++;
          autoClick.opacity = 0;
          autoClick.touchable = false;
          autoClick.modified();
          score = score - 50;
          click();
        });
        var shopShowing = false;
        shop.onPointDown.add(function () {
          if (shopShowing) {
            shopShowing = false;
            autoClick.opacity = 0;
            autoClick.touchable = false;
            autoClick.modified();
          } else {
            shopShowing = true;
            autoClick.opacity = 1;
            autoClick.touchable = true;
            autoClick.modified();
          }
        });
        scene.onUpdate.add(function () {
          time += 1;
          if (time % 30 == 0) {
            clickSpeed.text = "分速" + (score / time * g.game.fps * 60).toFixed(0) + "枚";
            clickSpeed.invalidate();
          }
          if (time % 300 == 0) {
            if (autoClicker > 0) {
              score = autoClicker + score;
              click();
            }
          }
          if (score >= 50) {
            shop.opacity = 1;
            shop.touchable = true;
            shop.modified();
          } else {
            shop.opacity = 0;
            shop.touchable = false;
            shop.modified();
          }
        });
        scene.onMessage.add(function (msg) {
          if (msg.data.bet && msg.player.id == g.game.selfId) {
            // ユーザーが賭けた時
            score -= msg.data.bet[1]; // 賭けたクッキーの数を減らす
            cookieCounter.text = score.toString() + "枚";
            cookieCounter.invalidate();
          } else if (msg.data.dividend) {
            // 配当
            score += msg.data.dividend;
            cookieCounter.text = score.toString() + "枚";
            cookieCounter.invalidate();
          }
        });
      }

      // 投票画面の生成
      function gamble(scene, font, betInputLayer, choiceNum) {
        var selecting = true; // 賭けの選択肢を選んでいるか、(falseならポイントを入力中)
        var confirming = false; // 投票を終えたか
        var betInfo = [0, 0]; // ユーザーの賭けの情報

        // 投票画面の生成
        function keySum(array, betScoreIndi) {
          var num = 0;
          for (var i = 0; i < array.length; i++) {
            num += array[i] * Math.pow(10, array.length - i - 1);
          }
          if (selecting) {
            betScoreIndi.text = num.toString() + "番の選択肢に投票します";
            betScoreIndi.invalidate();
            if (num > choiceNum || num == 0) {
              confirmBtn.hide();
            } else {
              confirmBtn.show();
            }
          } else {
            if (!playersTable.hasOwnProperty(g.game.selfId)) {
              betScoreIndi.text = "先にクッキーを増やそう！";
              betScoreIndi.invalidate();
              confirmBtn.touchable = false;
              confirmBtn.opacity = 0;
              confirmBtn.modified();
              return num;
            }
            betScoreIndi.text = num.toString() + "個のクッキーを賭けます";
            betScoreIndi.invalidate();
            if (num > playersTable[g.game.selfId].score || num == 0) {
              confirmBtn.hide();
            } else {
              confirmBtn.show();
            }
          }
          return num;
        }
        var key1 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 900,
          y: 170,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key1"),
          touchable: true,
          local: true
        });
        var key2 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1000,
          y: 170,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key2"),
          touchable: true,
          local: true
        });
        var key3 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1100,
          y: 170,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key3"),
          touchable: true,
          local: true
        });
        var key4 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 900,
          y: 250,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key4"),
          touchable: true,
          local: true
        });
        var key5 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1000,
          y: 250,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key5"),
          touchable: true,
          local: true
        });
        var key6 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1100,
          y: 250,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key6"),
          touchable: true,
          local: true
        });
        var key7 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 900,
          y: 330,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key7"),
          touchable: true,
          local: true
        });
        var key8 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1000,
          y: 330,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key8"),
          touchable: true,
          local: true
        });
        var key9 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1100,
          y: 330,
          scaleX: 0.15,
          scaleY: 0.15,
          src: scene.asset.getImageById("key9"),
          touchable: true,
          local: true
        });
        var key0 = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          scaleX: 0.15,
          scaleY: 0.15,
          x: 1200,
          y: 330,
          src: scene.asset.getImageById("key0"),
          touchable: true,
          local: true
        });
        var confirmBtn = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1120,
          y: 420,
          scaleX: 0.3,
          scaleY: 0.3,
          src: scene.asset.getImageById("confirm"),
          touchable: true,
          local: true
        });
        var deleteBtn = new g.Sprite({
          scene: scene,
          parent: betInputLayer,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 940,
          y: 420,
          scaleX: 0.3,
          scaleY: 0.3,
          src: scene.asset.getImageById("delete"),
          touchable: true,
          local: true
        });
        var hide = new g.Sprite({
          scene: scene,
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1200,
          y: 210,
          scaleX: 0.3,
          scaleY: 0.3,
          src: scene.asset.getImageById("hide"),
          touchable: true,
          local: true
        });
        scene.append(hide);
        var betScoreIndi = new g.Label({
          scene: scene,
          parent: betInputLayer,
          font: font,
          fontSize: 30,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1050,
          y: 100,
          local: true
        });
        var confirmInfo = new g.Label({
          scene: scene,
          parent: betInputLayer,
          font: font,
          fontSize: 30,
          textColor: "#593018",
          text: "投票したい選択肢を入力しよう！",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1050,
          y: 50,
          local: true
        });
        var keyLen = [];
        key1.onPointDown.add(function () {
          keyLen.push(1);
          keySum(keyLen, betScoreIndi);
        });
        key2.onPointDown.add(function () {
          keyLen.push(2);
          keySum(keyLen, betScoreIndi);
        });
        key3.onPointDown.add(function () {
          keyLen.push(3);
          keySum(keyLen, betScoreIndi);
        });
        key4.onPointDown.add(function () {
          keyLen.push(4);
          keySum(keyLen, betScoreIndi);
        });
        key5.onPointDown.add(function () {
          keyLen.push(5);
          keySum(keyLen, betScoreIndi);
        });
        key6.onPointDown.add(function () {
          keyLen.push(6);
          keySum(keyLen, betScoreIndi);
        });
        key7.onPointDown.add(function () {
          keyLen.push(7);
          keySum(keyLen, betScoreIndi);
        });
        key8.onPointDown.add(function () {
          keyLen.push(8);
          keySum(keyLen, betScoreIndi);
        });
        key9.onPointDown.add(function () {
          keyLen.push(9);
          keySum(keyLen, betScoreIndi);
        });
        key0.onPointDown.add(function () {
          keyLen.push(0);
          keySum(keyLen, betScoreIndi);
        });
        deleteBtn.onPointDown.add(function () {
          keyLen.pop();
          keySum(keyLen, betScoreIndi);
        });
        var hiding = false;
        hide.onPointDown.add(function () {
          if (hiding) {
            betInputLayer.opacity = 1;
            betInputLayer.modified();
            hiding = false;
          } else {
            betInputLayer.opacity = 0;
            betInputLayer.modified();
            hiding = true;
          }
        });
        confirmBtn.onPointDown.add(function () {
          if (selecting) {
            betInfo[0] = keySum(keyLen, betScoreIndi);
            confirmInfo.text = betInfo[0].toString() + "に投票中";
            confirmInfo.invalidate();
            betScoreIndi.text = "賭けるクッキーの数を入力しよう！";
            betScoreIndi.invalidate();
            selecting = false;
          } else {
            betInfo[1] += keySum(keyLen, betScoreIndi);
            g.game.raiseEvent(new g.MessageEvent({
              bet: betInfo
            }));
            confirming = true;
            //　初期化
            betInfo = [0, 0];
            confirmInfo.text = "";
            confirmInfo.invalidate();
            betScoreIndi.text = "";
            betScoreIndi.invalidate();
            betInputLayer.destroy();
            hide.destroy();
          }
          keyLen = [];
        });
        scene.onMessage.add(function (msg) {
          if (msg.data.closeGamble && !confirming && !g.game.isActiveInstance()) {
            betInputLayer.destroy();
            hide.destroy();
          }
        });
      }
      function calcOdds(choice) {
        // オッズの表示
        var odds = {
          0: 0,
          1: 0,
          2: 0,
          3: 0,
          4: 0,
          5: 0,
          6: 0,
          7: 0,
          8: 0,
          9: 0
        };

        // 各選択肢での賭けられたポイントの合計を計算
        for (var key in playersTable) {
          var bet = playersTable[key].bet;
          var betAmount = bet[1];
          odds[bet[0]] += betAmount;
        }

        // 賭けられた総ポイントを計算
        var totalAmount = 0;
        for (var _key in odds) {
          totalAmount += odds[_key];
        }

        // オッズを計算して表示
        for (var _key2 in odds) {
          if (_key2 === "0") continue;
          var betChoice = Number(_key2);
          var oddsValue = totalAmount / odds[betChoice];
          if (_key2 == choice) {
            return oddsValue;
          }
        }
      }
      function odds(scene, font, oddsLayer) {
        var time = 0;
        var destroy = false; // 投票画面が破棄されたか
        var odds1 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 90,
          y: 20,
          local: true
        });
        var odds2 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 290,
          y: 20,
          local: true
        });
        var odds3 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 490,
          y: 20,
          local: true
        });
        var odds4 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 690,
          y: 20,
          local: true
        });
        var odds5 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 890,
          y: 20,
          local: true
        });
        var odds6 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 1090,
          y: 20,
          local: true
        });
        var odds7 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 370,
          y: 50,
          local: true
        });
        var odds8 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 570,
          y: 50,
          local: true
        });
        var odds9 = new g.Label({
          scene: scene,
          parent: oddsLayer,
          font: font,
          fontSize: 25,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 770,
          y: 50,
          local: true
        });
        scene.onUpdate.add(function () {
          if (!gambleTime) return;
          time++;
          if (time % 30 === 0) {
            // オッズの表示
            var _odds = {
              0: 0,
              1: 0,
              2: 0,
              3: 0,
              4: 0,
              5: 0,
              6: 0,
              7: 0,
              8: 0,
              9: 0
            };

            // 各選択肢での賭けられたポイントの合計を計算
            for (var key in playersTable) {
              var bet = playersTable[key].bet;
              var betAmount = bet[1];
              _odds[bet[0]] += betAmount;
            }

            // 賭けられた総ポイントを計算
            var totalAmount = 0;
            for (var _key3 in _odds) {
              totalAmount += _odds[_key3];
            }
            // オッズを計算して表示
            for (var _key4 in _odds) {
              if (_key4 === "0") continue;
              var betChoice = Number(_key4);
              var oddsValue = totalAmount / _odds[betChoice];
              if (_odds[betChoice] != 0) {
                var label = eval("odds".concat(_key4));
                label.text = "".concat(_key4, "\u756A: ").concat(oddsValue.toFixed(3), "\u500D");
                label.invalidate();
              }
            }
          }
        });
        scene.onMessage.add(function (msg) {
          if (msg.data.result && destroy == false) {
            // 結果発表されたら
            oddsLayer.destroy();
            destroy = true;
          }
        });
      }
      function dividend(scene, font, dividendLayer, resultInfo) {
        var time = 0;
        var destroy = false;
        var dividedResult = new g.Label({
          scene: scene,
          parent: dividendLayer,
          font: font,
          fontSize: 50,
          textColor: "#593018",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 640,
          y: 100,
          local: true
        });
        scene.asset.getAudioById("JRA").play();
        if (!g.game.isActiveInstance()) {
          var mybet = playersTable[g.game.selfId].bet[0];
          if (mybet === resultInfo) {
            var myOdds = calcOdds(mybet);
            var getScore = Math.floor(playersTable[g.game.selfId].bet[1] * myOdds);
            dividedResult.text = "\u914D\u5F53: ".concat(getScore, "\u679A");
            dividedResult.invalidate();
            g.game.raiseEvent(new g.MessageEvent({
              dividend: getScore
            }));
          } else {
            g.game.raiseEvent(new g.MessageEvent({
              dividend: 0
            }));
          }
        }
        scene.onUpdate.add(function () {
          time++;
          if (time >= 30 * 6 && !destroy) {
            dividendLayer.destroy();
            destroy = true;
          }
          if (time % 40 == 0) {
            dividendLayer.hide();
          } else if (time % 20 == 0) {
            dividendLayer.show();
          }
        });
      }
      function ranking(scene, font, rankingLayer) {
        var R1 = new g.Label({
          scene: scene,
          parent: rankingLayer,
          font: font,
          fontSize: 25,
          textColor: "#A66038",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 200,
          y: 490,
          local: true
        });
        var R2 = new g.Label({
          scene: scene,
          parent: rankingLayer,
          font: font,
          fontSize: 22,
          textColor: "#A66038",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 200,
          y: 520,
          local: true
        });
        var R3 = new g.Label({
          scene: scene,
          parent: rankingLayer,
          font: font,
          fontSize: 19,
          textColor: "#A66038",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 200,
          y: 550,
          local: true
        });
        var R4 = new g.Label({
          scene: scene,
          parent: rankingLayer,
          font: font,
          fontSize: 16,
          textColor: "#A66038",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 200,
          y: 580,
          local: true
        });
        var R5 = new g.Label({
          scene: scene,
          parent: rankingLayer,
          font: font,
          fontSize: 13,
          textColor: "#A66038",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 200,
          y: 610,
          local: true
        });
        var yourRank = new g.Label({
          scene: scene,
          parent: rankingLayer,
          font: font,
          fontSize: 28,
          textColor: "#261109",
          text: "",
          anchorX: 0.5,
          anchorY: 0.5,
          x: 300,
          y: 690,
          local: true
        });
        var Rankbutton = new g.Sprite({
          scene: scene,
          parent: rankingLayer,
          src: scene.assets["ranking"],
          x: 80,
          y: 650,
          anchorX: 0.5,
          anchorY: 0.5,
          scaleX: 0.4,
          scaleY: 0.4,
          local: true,
          touchable: true
        });
        R1.hide();
        R2.hide();
        R3.hide();
        R4.hide();
        R5.hide();
        yourRank.hide();
        var showRank = false;
        Rankbutton.pointDown.add(function () {
          if (showRank) {
            R1.hide();
            R2.hide();
            R3.hide();
            R4.hide();
            R5.hide();
            yourRank.hide();
            showRank = false;
          } else {
            R1.show();
            R2.show();
            R3.show();
            R4.show();
            R5.show();
            yourRank.show();
            showRank = true;
          }
        });
        scene.onUpdate.add(function () {
          var sortedIDs = Object.keys(playersTable).sort(function (a, b) {
            return playersTable[b].score - playersTable[a].score;
          });
          // 上から5番目までのスコアと名前を出力
          for (var i = 0; i < 5 && i < sortedIDs.length; i++) {
            var playerID = sortedIDs[i];
            var player = playersTable[playerID];
            var label = eval("R".concat(i + 1));
            label.text = "".concat(i + 1, "\u4F4D: ").concat(player.name, " ").concat(player.score, "\u679A");
            label.invalidate();
          }
          // 自分の順位を出力
          if (!g.game.isActiveInstance()) {
            var myID = g.game.selfId;
            var myRank = sortedIDs.indexOf(myID) + 1;
            yourRank.text = "\u3042\u306A\u305F\u306F".concat(myRank, "\u4F4D\u3067\u3059");
            yourRank.invalidate();
          }
        });
      }

      // エントリポイント
      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["cookie", "startGamble", "key1", "key2", "key3", "key4", "key5", "key6", "key7", "key8", "key9", "key0", "hide", "delete", "confirm", "close", "ranking", "JRA", "shop", "autoClick"]
        });
        var font = new g.DynamicFont({
          game: g.game,
          fontFamily: g.FontFamily.SansSerif,
          fontWeight: g.FontWeight.Bold,
          size: 50
        });
        var streamerLayer = new g.E({
          scene: scene,
          parent: scene,
          local: true
        });
        var registerLayer = new g.E({
          scene: scene,
          parent: scene,
          local: true
        });
        var cookieLayer = new g.E({
          scene: scene,
          parent: scene,
          local: true
        });
        var oddsLayer = new g.E({
          scene: scene,
          parent: scene,
          local: true
        });
        var rankingLayer = new g.E({
          scene: scene,
          parent: scene,
          local: true
        });
        scene.onLoad.add(function () {
          // ここからゲーム内容を記述します
          g.game.onPlayerInfo.add(function (ev) {
            var player = ev.player;
            var myID = player.id;
            playersTable[myID] = {
              name: player.name,
              // 名前
              score: 0,
              // スコア
              betting: false,
              // 賭け中かどうか
              bet: [0, 0] // 賭けた選択肢と賭けたクッキ賭けたクッキーの数
            };
          });

          g.game.onJoin.add(function (ev) {
            var broadcastPlyerId = ev.player.id;
            if (g.game.selfId === broadcastPlyerId) {
              streamer(scene, font, streamerLayer);
            }
          });
          register(scene, font, registerLayer, cookieLayer, rankingLayer);
          scene.onMessage.add(function (msg) {
            if (msg.data.click) {
              // クッキーをクリックしたとき
              playersTable[msg.player.id].score = msg.data.click;
              console.log(playersTable);
            } else if (msg.data.startGamble) {
              // 賭け開始
              var betInputLayer = new g.E({
                scene: scene,
                parent: scene,
                local: true
              });
              var _oddsLayer = new g.E({
                scene: scene,
                parent: scene,
                local: true
              });
              console.log("startGamble");
              gambleTime = true;
              gamble(scene, font, betInputLayer, msg.data.choiceNum);
              odds(scene, font, _oddsLayer);
            } else if (msg.data.bet) {
              // ユーザーが賭けたとき
              playersTable[msg.player.id].bet = msg.data.bet;
              playersTable[msg.player.id].betting = true;
              playersTable[msg.player.id].score -= msg.data.bet[1];
              console.log(playersTable);
            } else if (msg.data.result) {
              var dividendLayer = new g.E({
                scene: scene,
                parent: scene,
                local: true
              });
              // 結果発表
              dividend(scene, font, dividendLayer, msg.data.result);
            } else if (msg.data.dividend) {
              // 配当
              playersTable[msg.player.id].score += msg.data.dividend;
              playersTable[msg.player.id].bet = [0, 0];
              playersTable[msg.player.id].betting = false;
            }
          });
          // ここまでゲーム内容を記述します
        });

        g.game.pushScene(scene);
      }
      module.exports = main;
    }, {
      "@akashic-extension/resolve-player-info": 5
    }]
  }, {}, [6])(6);
});